/*  Header file for IR decoding 
 *
 *  Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */

/* 0x11		Daikin indicator code 1
 * Oxda		Daikin indicator code 2
 * 0x97		Address code
 * 0x0		terminator
 * 0x8f		command indicator
 * zzzz		COMMAND BYTE (see below)
 * 0x0 		terminator
 * 0xyy		yy = CRC */
#define daikin_bytes 8

/* toggle, + command/address + info */
#define RC5_bytes 3

/* mode + toggle, + command/address + info */
#define RC6_bytes 4

/* address byte, ~address byte, command byte, ~command byte */
#define NEC_bytes 4

// kind of remotes in translation table
typedef enum 
{
	NEC,
	DAIKIN,
	SONY,
	RC6,
	RC5,
	END
} Remote;
 
// format of decoder-table
typedef struct {
	Remote 	type;		// hold the type of remote
	int		addr_b;		// address byte
	int 	addr_c;		// address code
	int		offset;		// byte to check
	int		command;	// command byte
	char 	*desc;		// description

} decode_tbl;

// translate address to device for philips (RC5/RC6) and Sony
typedef struct {
	int		addr;
	char	*desc;
} ph_a;

// decoder translation table 
decode_tbl descr[] =
{
//type addr_b _c offset command desciption	
{DAIKIN, 0, 0x11, 13, 0x1, "ON/OFF"},			// daikin ARC437A3
{DAIKIN, 0, 0x11, 13, 0x2, "AUTO"},
{DAIKIN, 0, 0x11, 13, 0x3, "OFF TIMER"},
{DAIKIN, 0, 0x11, 13, 0x8, "TURBO"},
{DAIKIN, 0, 0x11, 13, 0x9, "ANTI-POLLEN"},
{DAIKIN, 0, 0x11, 13, 0x10, "FAN SPEED"},
{DAIKIN, 0, 0x11, 13, 0x12, "RELAX"},
{DAIKIN, 0, 0x11, 13, 0x13, "LOCK"},
{DAIKIN, 0, 0x11, 13, 0x38, "BRIGHTNESS"},

{NEC, 1, 0xBF, 2, 0, "ON/OFF"},					// small remote
{NEC, 1, 0xBF, 2, 0x1, "VOLUME +"},
{NEC, 1, 0xBF, 2, 0x2, "FUNC / STOP"},
{NEC, 1, 0xBF, 2, 0x4, "||<< (fast backward)"},
{NEC, 1, 0xBF, 2, 0x5, ">|| (play)"},
{NEC, 1, 0xBF, 2, 0x6, ">>|| (fast forward"},
{NEC, 1, 0xBF, 2, 0x8, "V (arrow down)"},
{NEC, 1, 0xBF, 2, 0x9, "VOLUME -"},
{NEC, 1, 0xBF, 2, 0xa, "^ (arrow up)"},
{NEC, 1, 0xBF, 2, 0xc, "0"},
{NEC, 1, 0xBF, 2, 0xd, "EQ"},
{NEC, 1, 0xBF, 2, 0xe, "ST / REPT"},
{NEC, 1, 0xBF, 2, 0x10, "1"},
{NEC, 1, 0xBF, 2, 0x11, "2"},
{NEC, 1, 0xBF, 2, 0x12, "3"},
{NEC, 1, 0xBF, 2, 0x14, "4"},
{NEC, 1, 0xBF, 2, 0x15, "5"},
{NEC, 1, 0xBF, 2, 0x16, "6"},
{NEC, 1, 0xBF, 2, 0x18, "7"},
{NEC, 1, 0xBF, 2, 0x19, "8"},
{NEC, 1, 0xBF, 2, 0x1a, "9"},

{NEC, 1, 0x10, 2, 0, "ON/OFF"},					// Humax
{NEC, 1, 0x10, 2, 0x2, "SOURCE"},
{NEC, 1, 0x10, 2, 0x3, "1"},
{NEC, 1, 0x10, 2, 0x4, "2"},
{NEC, 1, 0x10, 2, 0x5, "3"},
{NEC, 1, 0x10, 2, 0x6, "4"},
{NEC, 1, 0x10, 2, 0x7, "5"},
{NEC, 1, 0x10, 2, 0x8, "6"},
{NEC, 1, 0x10, 2, 0x9, "7"},
{NEC, 1, 0x10, 2, 0xa, "8"},
{NEC, 1, 0x10, 2, 0xb, "9"},
{NEC, 1, 0x10, 2, 0xc, "0"},
{NEC, 1, 0x10, 2, 0xd, "TV/RADIO"},
{NEC, 1, 0x10, 2, 0xe, "MENU"},
{NEC, 1, 0x10, 2, 0xf, "CHANNEL -"},
{NEC, 1, 0x10, 2, 0x10, "CHANNEL +"},
{NEC, 1, 0x10, 2, 0x11, "up"},
{NEC, 1, 0x10, 2, 0x12, "left"},
{NEC, 1, 0x10, 2, 0x13, "OK"},
{NEC, 1, 0x10, 2, 0x14, "right"},
{NEC, 1, 0x10, 2, 0x15, "down"},
{NEC, 1, 0x10, 2, 0x16, "EXIT"},
{NEC, 1, 0x10, 2, 0x18, "SOUND ON/OFF"},
{NEC, 1, 0x10, 2, 0x1a, "YELLOW"},
{NEC, 1, 0x10, 2, 0x1b, "GUIDE"},
{NEC, 1, 0x10, 2, 0x1c, "RED"},
{NEC, 1, 0x10, 2, 0x1d, "GREEN"},
{NEC, 1, 0x10, 2, 0x1e, "BLUE"},
{NEC, 1, 0x10, 2, 0x1f, "VOLUME +"},
{NEC, 1, 0x10, 2, 0x40, "VOLUME -"},
{NEC, 1, 0x10, 2, 0x41, "BACK"},
{NEC, 1, 0x10, 2, 0x42, "OPT +"},
{NEC, 1, 0x10, 2, 0x43, "Info"},
{NEC, 1, 0x10, 2, 0x45, "?"},
{NEC, 1, 0x10, 2, 0x46, "SUB"},
{NEC, 1, 0x10, 2, 0x4b, "TV portal"},
{NEC, 1, 0x10, 2, 0x4c, "SLEEP"},
{NEC, 1, 0x10, 2, 0x4d, "LIST"},
{NEC, 1, 0x10, 2, 0x4e, "WIDE"},
{NEC, 1, 0x10, 2, 0x4f, "V-FORMAT"},
{NEC, 1, 0x10, 2, 0x60, "> (play)"},
{NEC, 1, 0x10, 2, 0x61, "O (record"},
{NEC, 1, 0x10, 2, 0x62, "|| (pauze)"},
{NEC, 1, 0x10, 2, 0x63, "# (stop)"},
{NEC, 1, 0x10, 2, 0x64, ">> (fast forward"},
{NEC, 1, 0x10, 2, 0x65, "<< (fast backward)"},
{NEC, 1, 0x10, 2, 0x66, "|<< (skip backward)"},
{NEC, 1, 0x10, 2, 0x67, ">>| (skip forward)"},
{NEC, 1, 0x10, 2, 0x6a, "+pag"},
{NEC, 1, 0x10, 2, 0x6b, "pag"},
{NEC, 1, 0x10, 2, 0x6c, "|>"},
{NEC, 1, 0x10, 2, 0x6e, "TEXT"},
{NEC, 1, 0x10, 2, 0x6f, "MEDIA"},

{NEC, 1, 0xfb, 2, 0x0, "CHANNEL +"},			//VIZIO
{NEC, 1, 0xfb, 2, 0x1, "CHANNEL -"},
{NEC, 1, 0xfb, 2, 0x2, "VOLUME +"},
{NEC, 1, 0xfb, 2, 0x3, "VOLUME -"},
{NEC, 1, 0xfb, 2, 0x8, "ON/OFF"},
{NEC, 1, 0xfb, 2, 0x9, "Mute"},
{NEC, 1, 0xfb, 2, 0xa, "Mts - play"},
{NEC, 1, 0xfb, 2, 0xb, "Audio"},
{NEC, 1, 0xfb, 2, 0xe, "Sleep - pauze"},
{NEC, 1, 0xfb, 2, 0x11, "1"},
{NEC, 1, 0xfb, 2, 0x12, "2"},
{NEC, 1, 0xfb, 2, 0x13, "3"},
{NEC, 1, 0xfb, 2, 0x14, "4"},
{NEC, 1, 0xfb, 2, 0x15, "5"},
{NEC, 1, 0xfb, 2, 0x16, "6"},
{NEC, 1, 0xfb, 2, 0x17, "7"},
{NEC, 1, 0xfb, 2, 0x18, "8"},
{NEC, 1, 0xfb, 2, 0x19, "9"},
{NEC, 1, 0xfb, 2, 0x10, "0"},
{NEC, 1, 0xfb, 2, 0x1a, "Last"},
{NEC, 1, 0xfb, 2, 0x1b, "Info"},
{NEC, 1, 0xfb, 2, 0x1c, "Guide"},
{NEC, 1, 0xfb, 2, 0x2f, "Input"},
{NEC, 1, 0xfb, 2, 0x39, "cc - stop"},
{NEC, 1, 0xfb, 2, 0x40, "ZOOM +"},
{NEC, 1, 0xfb, 2, 0x41, "ZOOM -"},
{NEC, 1, 0xfb, 2, 0x43, "Menu"},
{NEC, 1, 0xfb, 2, 0x44, "OK"},
{NEC, 1, 0xfb, 2, 0x45, "up"},
{NEC, 1, 0xfb, 2, 0x46, "down"},
{NEC, 1, 0xfb, 2, 0x47, "left"},
{NEC, 1, 0xfb, 2, 0x48, "right"},
{NEC, 1, 0xfb, 2, 0x49, "Exit"},
{NEC, 1, 0xfb, 2, 0x5a, "Component - >> (fast forward"},
{NEC, 1, 0xfb, 2, 0x51, "AV - << (fast backward)"},
{NEC, 1, 0xfb, 2, 0x60, "PIP"},
{NEC, 1, 0xfb, 2, 0x61, "PIP size"},
{NEC, 1, 0xfb, 2, 0x63, "PIP ch -"},
{NEC, 1, 0xfb, 2, 0x64, "PIP ch +"},
{NEC, 1, 0xfb, 2, 0x65, "Freeze"},
{NEC, 1, 0xfb, 2, 0x66, "swap"},
{NEC, 1, 0xfb, 2, 0x67, "Mode"},
{NEC, 1, 0xfb, 2, 0x77, "Wide - record"},
{NEC, 1, 0xfb, 2, 0x98, "RGB"},
{NEC, 1, 0xfb, 2, 0xD6, "TV  - |<< (skip backward)"},
{NEC, 1, 0xfb, 2, 0xc6, "HDMI - >>| (skip forward)"},
{NEC, 1, 0xfb, 2, 0xff, "Enter"},

{RC6, 2, 0x4, 3, 0x0, "0"},					//Philips DVD, RC6
{RC6, 2, 0x4, 3, 0x1, "1"},	
{RC6, 2, 0x4, 3, 0x2, "2"},	
{RC6, 2, 0x4, 3, 0x3, "3"},	
{RC6, 2, 0x4, 3, 0x4, "4"},	
{RC6, 2, 0x4, 3, 0x5, "5"},	
{RC6, 2, 0x4, 3, 0x6, "6"},	
{RC6, 2, 0x4, 3, 0x7, "7"},	
{RC6, 2, 0x4, 3, 0x8, "8"},	
{RC6, 2, 0x4, 3, 0x9, "9"},	
{RC6, 2, 0x4, 3, 0xf, "Info"},	
{RC6, 2, 0x4, 3, 0x1d, "Repeat"},
{RC6, 2, 0x4, 3, 0x20, " >>| (skip forward)"},	
{RC6, 2, 0x4, 3, 0x21, "|<< (skip backward)"},	
{RC6, 2, 0x4, 3, 0x2c, "Start/Pause"},
{RC6, 2, 0x4, 3, 0x30, "Pause"},		
{RC6, 2, 0x4, 3, 0x31, "stop"},	
{RC6, 2, 0x4, 3, 0x3b, "Repeat A-B"},
{RC6, 2, 0x4, 3, 0x42, "Eject"},	
{RC6, 2, 0x4, 3, 0x4b, "Subtitle"},	
{RC6, 2, 0x4, 3, 0x4e, "Audio / create MP35"},
{RC6, 2, 0x4, 3, 0x54, "Guide / Menu"},		
{RC6, 2, 0x4, 3, 0x58, "^ (up)"},	
{RC6, 2, 0x4, 3, 0x59, "v (down)"},	
{RC6, 2, 0x4, 3, 0x5a, "< (right)"},	
{RC6, 2, 0x4, 3, 0x5b, "> (left)"},	
{RC6, 2, 0x4, 3, 0x5c, "OK"},
{RC6, 2, 0x4, 3, 0x7e, "USB"},
{RC6, 2, 0x4, 3, 0x82, "Setup"},
{RC6, 2, 0x4, 3, 0x83, "Back"},	
{RC6, 2, 0x4, 3, 0x85, "View"},	
{RC6, 1, 0x0, 2, 0xC2, "Cinema Go"},	
{RC6, 2, 0x4, 3, 0xc7, "ON/OFF"},
{RC6, 2, 0x4, 3, 0xc8, "T-C"},	
{RC6, 2, 0x4, 3, 0xd1, "Menu"},
{RC6, 2, 0x4, 3, 0xf7, "Zoom"},	
	
{RC5, 1, 0x0, 2, 0x0, "0"},					//Philips TV, RC5
{RC5, 1, 0x0, 2, 0x1, "1"},	
{RC5, 1, 0x0, 2, 0x2, "2"},	
{RC5, 1, 0x0, 2, 0x2, "3"},	
{RC5, 1, 0x0, 2, 0x4, "4"},	
{RC5, 1, 0x0, 2, 0x5, "5"},	
{RC5, 1, 0x0, 2, 0x6, "6"},	
{RC5, 1, 0x0, 2, 0x7, "7"},	
{RC5, 1, 0x0, 2, 0x8, "8"},	
{RC5, 1, 0x0, 2, 0x9, "9"},	
{RC5, 1, 0x0, 2, 0xc, "ON/OFF"},
{RC5, 1, 0x0, 2, 0x17, "Volume down"},	
{RC5, 1, 0x0, 2, 0x20, "Volume up"},
{RC5, 1, 0x0, 2, 0x1b, "Mute"},


{SONY, 1, 0x1a, 0, 0x0, "1"},				//Sony DVD, 20 bit code
{SONY, 1, 0x1a, 0, 0x1, "2"},				// RMT - B107P
{SONY, 1, 0x1a, 0, 0x2, "3"},	
{SONY, 1, 0x1a, 0, 0x3, "4"},
{SONY, 1, 0x1a, 0, 0x4, "5"},
{SONY, 1, 0x1a, 0, 0x5, "6"},	
{SONY, 1, 0x1a, 0, 0x6, "7"},
{SONY, 1, 0x1a, 0, 0x7, "8"},
{SONY, 1, 0x1a, 0, 0x8, "9"},	
{SONY, 1, 0x1a, 0, 0x9, "0"},
{SONY, 1, 0x1a, 0, 0xf, "clear"},
{SONY, 1, 0x1a, 0, 0x15, "On/OFF"},
{SONY, 1, 0x1a, 0, 0x16, "Eject"},
{SONY, 1, 0x1a, 0, 0x18, "Stop"},
{SONY, 1, 0x1a, 0, 0x19, "Pause"},

{SONY, 1, 0x1a, 0, 0x1b, "Fast left"},
{SONY, 1, 0x1a, 0, 0x1c, "Fast Right"},
{SONY, 1, 0x1a, 0, 0x29, "Pop up / Menu"},
{SONY, 1, 0x1a, 0, 0x2c, "Top menu / repeat"},
{SONY, 1, 0x1a, 0, 0x30, "Skipp left"},
{SONY, 1, 0x1a, 0, 0x31, "Skipp right"},
{SONY, 1, 0x1a, 0, 0x32, "Play"},
{SONY, 1, 0x1a, 0, 0x33, "fast left"},
{SONY, 1, 0x1a, 0, 0x34, "fast right"},
{SONY, 1, 0x1a, 0, 0x38, "Stop"},
{SONY, 1, 0x1a, 0, 0x39, "arrow up / pause"},
{SONY, 1, 0x1a, 0, 0x3a, "arrow down"},
{SONY, 1, 0x1a, 0, 0x3b, "arrow left"},	
{SONY, 1, 0x1a, 0, 0x3c, "arrow right"},
{SONY, 1, 0x1a, 0, 0x3d, "OK"},
{SONY, 1, 0x1a, 0, 0x3e, "Disc Skip"},
{SONY, 1, 0x1a, 0, 0x3f, "Options"},
{SONY, 1, 0x1a, 0, 0x41, "Display"},
{SONY, 1, 0x1a, 0, 0x42, "Home"},
{SONY, 1, 0x1a, 0, 0x43, "Return"},	
{SONY, 1, 0x1a, 0, 0x57, "Skipp left"},	
{SONY, 1, 0x1a, 0, 0x56, "Skipp Right"},
{SONY, 1, 0x1a, 0, 0x58, "Menu/No"},
{SONY, 1, 0x1a, 0, 0x5b, "Name Edit/Character"},
{SONY, 1, 0x1a, 0, 0x5e, "Heart"},
{SONY, 1, 0x1a, 0, 0x60, "Theatre"},
{SONY, 1, 0x1a, 0, 0x64, "Audio"},
{SONY, 1, 0x1a, 0, 0x66, "Blue"},
{SONY, 1, 0x1a, 0, 0x67, "Red"},
{SONY, 1, 0x1a, 0, 0x68, "Green"},	
{SONY, 1, 0x1a, 0, 0x69, "Yellow"},
{SONY, 1, 0x1a, 0, 0x76, "Step left"},
{SONY, 1, 0x1a, 0, 0x75, "Step right"},	


{SONY, 1, 0x10, 0, 0x60, "sleep"},				//Sony tunes, 12 bit code
{SONY, 1, 0x10, 0, 0x62, "Clock/Select"},		// RM - SCL1
{SONY, 1, 0x10, 0, 0x65, "Timer-Set"},
{SONY, 1, 0x10, 0, 0x15, "ON/OFF"},
{SONY, 1, 0x10, 0, 0x4c, "Scroll"},
{SONY, 1, 0x10, 0, 0xf, "Tuner/ Band"},
{SONY, 1, 0x10, 0, 0x4d, "Dimmer"},
{SONY, 1, 0x10, 0, 0x12, "Volume +"},
{SONY, 1, 0x10, 0, 0x13, "Volume -"},
{SONY, 1, 0x10, 0, 0x7a, "Groove"},

{SONY, 1, 0x10, 0, 0x4B, "Display"},

{SONY, 1, 0x11, 0, 0xd, "Check"},

{SONY, 1, 0x12, 0, 0x3f, "Surround"},
{SONY, 1, 0x12, 0, 0x7c, "Music Menu"},
{SONY, 1, 0x12, 0, 0x31, "DBFB"},
{SONY, 1, 0x12, 0, 0x69, "Function"},
{END,0,0,0,0,"END"}
};

// RC5 address codes (apply also for RC6, which might have even more)
ph_a philips_add[] =
{
{0,"TV 1 (TV receiver 1)"},
{1,"TV 2 (functions and command numbers as system 0)"},
{2,"Txt (teletext)"},
{3,"Extension to TV 1 and TV 2"},
{4,"LV (LaserVision player), DVD"},
{5,"VCR 1 (video cassette recorder 1)"},
{6,"VCR 2 (functions and commands as system 5)"},
{7,"Reserved"},
{8,"Sat 1 (satellite TV receiver 1)"},
{9,"Extension to VCR 1 and VCR 2"},
{10,"Sat 2 (functions and commands as system 8)"},
{11,"Reserved"},
{12,"CD-Video (compact disc video player)"},
{13,"Reserved"},
{14,"CD-Photo (photo on compact disc player)"},
{15,"Reserved"},
{16,"Preamp 1 (audio preamplifier 1)"},
{17,"Tuner (radio tuner)"},
{18,"Rec 1 (analog cassette recorder)"},
{19,"Preamp 2 (functions and commands as system 16)"},
{20,"CD (compact disc player)"},
{21,"Combi (audio stack or record player)"},
{22,"Sat (audio satellite)"},
{23,"Rec 2 (functions and commands as system 18)"},
{24,"Reserved"},
{25,"Reserved"},
{26,"CD-R (compact disc recorder)"},
{27,"Reserved"},
{28,"Reserved"},
{29,"Lighting"},
{30,"Reserved"},
{31,"Reserved"},
};


ph_a sony_add[] =
{
{0,"TV 1 (TV receiver 1)"},
{1,"TV 2 (functions and command numbers as system 0)"},
{2,"VCR 1 (video cassette recorder 1)"},
{3,"VCR 2 (functions and commands as system 5)"},
{6,"LV (LaserVision player)"},
{12,"Surround Sound"},
{16,"Cassette Deck/Tuner"},
{17,"CD (compact disc player) / Tuner"},
{18,"Equalizer"},
{26,"DVD"},
{100,"END"},
};

 
/* 
 * Daikin code ARC437A3 / to MC707VM
 * it will sent 2 messages of code.
 * 
 * start :  flash/on ~ 3500usec	/ gap/off ~ 1750
 * first message
 * end first message gap/off ~29900  flash/on ~3450  gap/off ~1700
 * second message
 * end second message gap/off ~LONG...
 * 
 * flash/on	400 - 600us followed by
 * gap/off  < 500	0
 * gap/off  > 900	1
 * 
 * The second message will contain the real action to be performed
 * 
 * Format first message ( always the same)
 * 0x11		Daikin indicator code 1
 * Oxda		Daikin indicator code 2
 * 0x97		Address code
 * 0xf0		terminator
 * 0x0		
 * 0x0		
 * 0x0 		terminator
 * 0x72		CRC
 * 
 * Format second message: 
 * 0x11		Daikin indicator code 1
 * Oxda		Daikin indicator code 2
 * 0x97		Address code
 * 0x0			terminator
 * 0x8f		command indicator
 * zzzz		COMMAND BYTE (see below)
 * 0x0 		terminator
 * 0xyy		yy = CRC
 * 
 * zzzz  Command byte
 * Hex		command
 * 0x1		ON/OFF
 * 0x2		AUTO
 * 0x3		OFF TIMER
 * 0x8		TURBO
 * 0x9		ANTI-POLLEN
 * 0x10		FAN SPEED
 * 0x12		RELAX
 * 0x14		LOCK
 * 0x38 	BRIGHTNESS
 */
