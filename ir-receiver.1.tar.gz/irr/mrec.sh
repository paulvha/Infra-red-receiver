#!/bin/bash
# make infra-red receiver executable
# version 1.0 / paulvha / April 2017

cc -Wall -o receiver receiver.c -lbcm2835
