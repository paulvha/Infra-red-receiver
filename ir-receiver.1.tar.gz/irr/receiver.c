/* reading infrared- remote signal 
 * 
 * 
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */


#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdarg.h>
#include "receiver.h"
#include <bcm2835.h>

/** variables  */

/* neglect signals shorter then */
double neglect_pulse = 100;

/* apply Debug */
int DEBUG = 0;

/* do test pulse*/
int tst_pulse = 1;			// 1 = do test pulse

/* store received values */
store_rec rec_signal[MAX_COUNT];

/* store decoded bytes */
decode_rec	rec_bytes;

/* time out for read in seconds */
int read_time_out = 3;

/* display debug message
 * @param format : debug message to display and optional arguments
 *                 same as printf
 * @param level :  1 = RED, 2 = GREEN, 3 = YELLOW 4 = blue
 * info is only displayed if DEBUG had set for it*/

void p_printf (int level, char *format, ...)
{
    char	*col;
    va_list arg;
    
    //allocate memory
    col = malloc(strlen(format) + 20);
    		
    switch(level)
    {
		case 1:
			sprintf(col,REDSTR, format);
			break;
		case 2:
			sprintf(col,GRNSTR, format);
			break;		
		case 3:
			sprintf(col,YLWSTR, format);
			break;		
		case 4:
			sprintf(col,BLUSTR, format);
			break;
		default:
			sprintf(col,format);
	}
    
    if (DEBUG || level)
    {
		va_start (arg, format);
		vfprintf (stdout, col, arg);
		va_end (arg);
    }
    
    // release memory
    free(col);
}

/* return current time in useconds */
double get_current()
{
	struct	timeval	tv;

	gettimeofday(&tv,NULL);
	
	return((double) tv.tv_sec * 1000000 + (double) tv.tv_usec);
}

/* setup hardware  */
void hw_init() 
{
    if (!bcm2835_init()) {
        p_printf(1,"Can't init bcm2835!\n");
        exit(1);
    }
    
    // turn the power to IR receiver on.
    rec_power(ON);
    
    // enable input
	bcm2835_gpio_fsel(rec_pin, BCM2835_GPIO_FSEL_INPT);
	
	// if tst_pulse pulse requested (set low)
	if (tst_pulse)
	{
		bcm2835_gpio_fsel(pin_tst_pulse,BCM2835_GPIO_FSEL_OUTP);
		bcm2835_gpio_write(pin_tst_pulse, LOW);
	}
}

/* set tst_pulse on output pin to the requested level
 * if tst_pulse was enabled (-t) 
 */
void do_pulse(uint8_t level)
{
	if (tst_pulse) bcm2835_gpio_write(pin_tst_pulse, level);
}

/* end the program correctly */
void close_out(int end)
{
    // turn the power to MLX on.
    rec_power(OFF);
    
    // reset pins
	bcm2835_i2c_end();	
	
    // release BCM2835 library
    bcm2835_close();

    // exit with return code
    exit(end);
}

/* handle power ON or OFF for receiver */
void rec_power(int act)
{
	// set the power pin to output
	bcm2835_gpio_fsel(power_pin, BCM2835_GPIO_FSEL_OUTP); 
	
	if (act == ON) 
	{
		bcm2835_gpio_write(power_pin, HIGH);
		sleep (1);		// delay for the power to stabilize
	}
	else 	bcm2835_gpio_write(power_pin, LOW);
	
}

/* catch signals to close out correctly */
void signal_handler(int sig_num)
{
	switch(sig_num)
	{
		case SIGKILL:
		case SIGABRT:
		case SIGINT:
		case SIGTERM:
			p_printf(3, "\nStopping infra-red Reader.\n");
			close_out(2);
			break;
		default:
			p_printf(1,"\nneglecting signal %d.\n",sig_num);
	}
}

/* setup signals */
void set_signals()
{
	struct sigaction act;
	
	memset(&act, 0x0,sizeof(act));
	act.sa_handler = &signal_handler;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGTERM,&act, NULL);
	sigaction(SIGINT,&act, NULL);
	sigaction(SIGABRT,&act, NULL);
	sigaction(SIGSEGV,&act, NULL);
	sigaction(SIGKILL,&act, NULL);
}

/* get yes (1) or No (0) */
int yes_or_no(char *mess)
{
	char	answ;
	
	while (1)
	{
		p_printf(3, mess);
		
		scanf("%c",&answ); 
		
		if (answ == 'n' || answ == 'N') return(0);
		if (answ == 'y' || answ == 'Y') return(1);
	} 
}

/* read signal from the receiver */
int read_signal()
{
	double start_low = 0, stop_low = 0, prev=0;
    time_t loop;
	int	count = 0;

	p_printf (2,"Ready to start receiving\n");
	
	// set start 
	loop = time(NULL);

	do
	{
		// detect low level
		if ( ! bcm2835_gpio_lev(rec_pin))
		{
			// set starting low (once !)
			if (start_low == 0)  
			{
				start_low = get_current();
				do_pulse(HIGH);
			}
		}
		else 
		{	
			// get high if start low was set first
			if (start_low != 0 && stop_low == 0) 
			{
				stop_low = get_current();
				do_pulse(LOW);

				/* As long as not a dummy pulse
				 * The minimum burse length needs to be 280us
				 * according to the specification sheets
				 */
			
				if (stop_low - start_low > neglect_pulse)
				{
					if (DEBUG > 0) 
					{
						if (prev != 0)
							printf("\t followed by high time %f\n",start_low - prev);

						printf("pulse low time %f",stop_low - start_low);
					
						prev = stop_low;
					}
					
					rec_signal[count].start = start_low;
					rec_signal[count++].stop = stop_low;
					
					// reset time_out
					if (count > MAX_COUNT) loop = 0;
					else	loop = time(NULL);
					
					if (!DEBUG)
					{
						printf(".");
						fflush(stdout);
					}
				}
				else
				{
					if (DEBUG > 0)  printf("neglected pulse time %f\n",stop_low - start_low);
					prev=0;
				}	

				stop_low = start_low = 0;
			}
		}
			
		// time_out of X seconds		
	} while (time(0)- loop < read_time_out);	

	if (DEBUG > 0) printf("\ncount %d\n", count);
	else printf("\n");
	
	return(count);
}

/* calculate the Daikin CRC
 * 
 * @param start_ind : first byte in receive buf to include in CRC
 * @param end_ind : last byte in receive buf to include in CRC
 * return 0 = OK, -1 = ERROR
 */
int daikin_crc(int start_ind, int end_ind)
{
	int lp; 
	char crc = 0;
	
	// add the received values (lsb order)
	for (lp = start_ind; lp < end_ind; lp++)
		crc += rec_bytes.buf[lp];
	
	// only keep the last 8 bits	
	crc &= 0xff; 
	
	// check that CRC are the same
	if (crc != rec_bytes.buf[end_ind])
	{
		p_printf(1,"crc error. received %x, calculated %x\n", 
		rec_bytes.buf[end_ind], crc);
		return(-1);
	}
	else
		if (DEBUG > 0) printf("crc is OK \n");
	
	return(0);
}
/* decode Sony
 * will determine whether it is 12, 15 or 20 bit protocol
 */

int decode_data_sony(int count)
{
	int lp,	started = 0;	// loop controls
	int tmp;				// hold byte during decode
	int bit;				// remember which bit is being decoded in byte
	int gb_ind=0;			// byte offset in receive/decoded buffer
	int bit_count;			// message count
	int s_version = 0 ;		// sony version
	double check_gap, check_flash;
		
	p_printf(2, "Decoding Sony protocol\n");

	rec_bytes.type = SONY;

	// determine whether 12-bit, 15-bit or 20 bit version
	for (lp = 0 ; lp < count -1 ; lp++)
	{
		if ( rec_signal[lp+1].start - rec_signal[lp].stop > 10000)
		{
			if (lp == 12 || lp == 15 || lp == 20)
			{
				s_version = lp;
				break;
			}
		}
	}
	
	if (s_version == 0)
	{
		p_printf(1, "Could not detect 12, 15 or 20 bit Sony signal\n");
		return(-1);
	}
	else
		p_printf(3,"Detected %d-bit signal\n",s_version);


	for (lp = 0 ; lp < count -1 ; lp++)
	{
		// calculate results
		check_flash = rec_signal[lp].stop - rec_signal[lp].start;		// current flash
		check_gap =rec_signal[lp+1].start - rec_signal[lp].stop;		// current gap		

		// skip messages headers
		if (check_flash > 2350 && check_flash  < 2500) 
		{
			if (DEBUG > 1) printf ("Sony message header was detected\n");
			tmp = bit = 0;		// reset byte and bit
			bit_count = 6;		// 7 command bits
			started++;
		}
	
		// start decoding message
		else if (started > 0)
		{
			// detect a 1- bit (1.2 ms pulse)
			if (check_flash> 1100)	tmp |=1 << bit;	

			// check we have done one byte, then save it
			if (bit++ == bit_count)
			{
				rec_bytes.buf[gb_ind++] = tmp;	// save discovered byte in buf
				rec_bytes.cnt = gb_ind;
				
				tmp = bit = 0;	// set for lSB decoding / reset received byte 
				
				// determine bytes and bits for 12, 15 or 20 bit version
				if (s_version == 12)
				{
					if (bit_count == 6) bit_count = 4;
					else break;
				}
				else if (s_version == 15)
				{
					if (bit_count == 6) bit_count = 7;
					else break;
				}			
				else
				{
					if (bit_count == 6) bit_count = 4;
					else if (bit_count == 4) bit_count = 7;
					else break;
				}
			}
			
			if(check_gap > 10000)
			{
				p_printf(3,"Detected repeat\n");
				break;
			}
		}
	}
	return(0);
}

/* decode Daikin remote
 * see decode.h for more info
 */
int decode_data_daikin(int count)
{
	int lp,	started = 0;	// loop controls
	int tmp;				// hold byte during decode
	int bit;				// remember which bit is being decoded in byte
	int gb_ind=0;			// byte offset in receive/decoded buffer
	int	st_crc = 0;			// remember start for CRC calculation
	int ms_cnt=1;			// message count
	int active_bit;			// bit to store
	double check_gap, check_flash;
		
	p_printf(2, "Decoding Daikin protocol\n");

	rec_bytes.type = DAIKIN;
	
	for (lp = 0 ; lp < count -1 ; lp++)
	{
		// calculate results
		check_flash = rec_signal[lp].stop - rec_signal[lp].start;		// current flash
		check_gap =rec_signal[lp+1].start - rec_signal[lp].stop;		// current gap		

		// skip messages headers
		if (check_flash > 3400 && check_flash  < 3900) 
		{
			if (DEBUG > 1) printf ("Daikin message header was detected\n");
			tmp = bit = 0;		// reset byte and bit
			started++;
		}
	
		// start decoding message
		else if (started > 0)
		{
			// detect a 1- bit ( 1ms - 2 ms pulse)
			if (check_gap > 1000)	active_bit = 1;
			else active_bit = 0;
			
			if (set_lsb_bit(&bit, active_bit , &tmp, &gb_ind, (daikin_bytes * ms_cnt)))
			{
				// perform CRC check if message bytes have been received
				if (daikin_crc(st_crc, gb_ind-1) == -1)	return(-1);	
				
				// remember start for CRC check for next byte
				st_crc = gb_ind;
				
				// check all bytes have been received
				if (ms_cnt++ == 2)
				{
					p_printf(2, "Received all bytes\n");
					break;
				}			
			}
		}
	}
	return(0);
}

/* determine what kind of decoding is required based on the start mark
 * and/or space
 */
 
int decode_data(int count)
{
	int i;
	
	double check_gap, check_flash;
	
	// calculate results
	check_flash = rec_signal[0].stop - rec_signal[0].start;		// current flash
	check_gap =rec_signal[1].start - rec_signal[0].stop;		// current gap
	
	// reset buffers
	for (i =0 ; i < MAX_BUF ; i++) rec_bytes.buf[i] = 0x0;	
	rec_bytes.cnt=0;

	// NEC MARK (9ms pulse) low
	if (check_flash > 8900)
		return(decode_data_nec(count));

	// Daikin ARC437A3
	if (check_flash > 3400 && check_flash < 3900)
		return(decode_data_daikin(count));

	// sony
	if (check_flash > 2350 && check_flash < 2500)
		return(decode_data_sony(count));

	// Philips RC-6
	if (check_flash  > 2600 && check_flash  < 3100)
		return(decode_data_rc6(count));

	// Philips RC-5
	if (check_flash > 800 && check_flash < 950 
	 && check_gap > 800 && check_gap < 950 )
		return(decode_data_rc5(count));		
			
	printf ("Remote signal not known\n");
	return(-1);

}
/* set bit value (either 0 or 1) & save byte if complete
 * bit = bit to set 
 * val = 0 or 1
 * tmp = byte to update
 * index = offset rec_bytes.buf
 * num_bytes = total amount of bytes expected
 * 
 * return 
 * 1 all bytes received
 * 0 not all bytes received
 */
int set_msb_bit(int *bit, int val, int *tmp, int * index, int num_bytes)
{
	if (DEBUG > 3) printf("set bit %d, to %d, current tmp %d, index %d, num_bytes %d\n", *bit, val, *tmp, *index, num_bytes);	
	
	if (val)	(*tmp) |=1 << *bit;		// set bit

	// check we have done one byte, then save it
	if ((*bit)-- == 0)
	{
		rec_bytes.buf[(*index)++] = *tmp;	// save discovered byte in buf
		rec_bytes.cnt = *index;
		
		*bit = 7;	// set for MSB decoding
		*tmp = 0;	// reset received byte 
		
		// if all bytes received
		if ((*index) > num_bytes -1)	return(1);
	}

	return(0);
}

/* set bit value (either 0 or 1) & save byte if complete
 * bit = bit to set 
 * val = 0 or 1
 * tmp = byte to update
 * index = offset rec_bytes.buf
 * num_bytes = total amount of bytes expected
 * 
 * return 
 * 1 all bytes received
 * 0 not all bytes received
 */
int set_lsb_bit(int *bit, int val, int *tmp, int * index, int num_bytes)
{
	if (DEBUG > 3) printf("set bit %d, to %d, current tmp %d, index %d, num_bytes %d\n", *bit, val, *tmp, *index, num_bytes);	
	
	if (val)	(*tmp) |=1 << *bit;		// set bit

	// check we have done one byte, then save it
	if ((*bit)++ == 7)
	{
		rec_bytes.buf[(*index)++] = *tmp;	// save discovered byte in buf
		rec_bytes.cnt = *index;
		
		*bit = 0;	// set for lSB decoding
		*tmp = 0;	// reset received byte 
		
		// if all bytes received
		if ((*index) > num_bytes -1)	return(1);
	}

	return(0);
}


/* 
 * ******************************************************
 * RC -6 structure
 * 
 * LS  SB | MB2 .. MB0 | T | a7...a0 | c7...c0 | free signal
 * 
 * LS = leader signal (2,66ms flash + 2 x 440 gap)
 * Start Byte = 1 = 440 flash / 440 gap
 * 
 * mb2 ... mb0  : mode bits ; 
 * 		for philips consumer always 0,0,0
 * 		for OEM and others other mode code
 * 
 * T = Toggle bit (alternates with each key pressed)
 * 
 * a7 ... a0  : control or address bits
 * 
 * c7 .. c0   : information or command
 * 
 * signal free : at least 2.66ms
 * 
 **********************************************************
 * 
 * RC-x follows Manchester decoding
 * 
 * slot time is 440us / 440 us = 880us
 * 1 =          flash / gap   (low / high)
 * 0 = 			gap   / flash (high / low)
 * 
 **********************************************************
 * Detection rules:
 * 
 * double time high: switch from 1 -> 0
 *  as 2 gaps are connected (the last of '1', the first of '0')
 * 
 * double time low : switch from 0 -> 1
 * 	as 2 flashes are connected (the last of '0', the first of '1')
 *  The '1' needs to be set/saved NOW.
 * 
 * single low or single high slot time, continue previous bit value
 * 
 **********************************************************
 * 
 * EXCEPTION for RC-6 with SLOT time for toggle bit as that double the 
 * normal slot time :  that is 880us / 880us = 1760us
 * 
 *** 
 * If bit 2 (mode bit 1) is '0':
 * 
 * if 4th low = 3 x 440 = ~1300, bit 3 (mode bit 0) is 0,  toggle bit = 1 
 * 	   '0' end with a flash (440us) and toggle bit '1' start with flash (880us)
 *
 * 	 if folllowed by high of 1300, bit a7  of control/address is a '0'   
 * 		  toggle bit '1' ending gap (880us) + first gap of '0' for bit a7
 * 
 * 	 else if followed by a high of 880us, bit a7 of control/address is a '1'
 * 		  toggle bit '1' gap (880us) + first flash of '1' for bit a7
 *  
 * if 4th low = 440 follow by a high of 880 us : bit 3 (mode bit 0) is 0, toggle = 0
 * 		'0' end with gap (440us), follow by a toggle bit '0' start of 880 us 
 * 
 * 		if follow by a low of 880 us, the bit A7 of control/address is '0'
 * 		toggle bit '0' ending flash (880us) + first gap of '0' for bit a7
 * 
 * 		if follow by a low of 1300 us, the bit A7 of control/address is '1'
 * 		toggle bit '0' endingflash (880us) + first flash of '1' for bit a7
 *** 
 * If bit 2 (mode bit 1) is '1':
 * 
 * if 4th low = 440us follow by a high of 1300 us : bit 3 (mode bit 0) is 1, toggle = 0
 * 		"1' start with flash (440us), ends with a gap (440us) and toggle bit '0' start with gap (880us)
 * 
 * 		if followed by a low of 880us, bit a7 of control/address is a '0'
 * 		toggle bit "0' ends with flash 880us, bit a7 start with gap(440us) for '0'
 * 
 * 		if followed with low of 1300us, bit a7 of control/address is a '1'
 * 		toggle bit '0' end with falsh 880us, bit a7 start with flash for '1'
 *  
 * if 4th low = 440 followed by high of 440us and a low of 880us, bit 3 (mode bit 0) is 1,  toggle bit = 1
 * 		'1' start with flash (440us), end with gap (440us) and toggle bit '1' starts with flash (880us)
 *   
 * 		if followed by a high of 880us, bit a7 of control/address is a '1'
 * 		toggle bit '1' ends with gap of 880us, bit a7 start with flash (440us) for '1'
 * 
 * 		if followed by a high of 1300us, bit a7 of control/address is a '0'
 * 		toggle bit '1' ends with gap of 880us, bit a7 start with gap(440us) for '0'
 * 
 *****************************************************
 * OTHERWISE : time low or time high >> 2 x 440 us
 * as that means error !!
 * 
 * 
 */

int decode_data_rc6(int count)
{
	int lp;					// loop variables
	int started = 0;
	int active_bit = 1;		// current active bit
	int toggle = 0;			// count to toggle bit
	int tmp;				// holds decoded byte
	int bit;				// MSB protocol
	int gb_ind;				// index to global buffer
	double check_gap, check_flash;
	
	p_printf(2, "Decoding RC-6 protocol\n");

	// set for RC6 encoding
	rec_bytes.type = RC6;
	
	for (lp = 0 ; lp < count -1 ; lp++)
	{
		// calculate results
		check_flash = rec_signal[lp].stop - rec_signal[lp].start;		// current flash
		check_gap =rec_signal[lp+1].start - rec_signal[lp].stop;		// current gap
		
		// find start of leader signal
		if (check_flash > 2600 && check_gap > 800 )
		{
			if (DEBUG) p_printf (2, "Found leader-signal flash: %f, gap: %f\n",check_flash,check_gap);
			started = 1;	// leader signal has been found
			gb_ind = 0;		// offset in buffer
			bit = 7;		// set for MSB
			tmp = 0;		// reset received byte 
		}
		
		// detect the active_bit based on the gap with the mandatory '1' after leader signal.
		else if (started == 1)
		{
			if (check_gap > 800) active_bit = 0;
			else if (check_gap < 500) active_bit = 1;
			else
			{
				p_printf(1,"Out of Sequence for RC-6 protocol\n");
				return(-1);	
			}

			started = 2; 	// time to start decoding
		}
						
		// start decoding
		else if (started == 2)
		{
			// set active bit && save byte if last bit
			if (set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC6_bytes))
			{
				p_printf(2,"Done all bytes\n");
				break;
			}
			
			// flag current can be toggle bit
			// Toggle bit in RC-6 is after 3 mode bits
			if (toggle++ == 2)	
			{
				// save mode byte (3 bits only)
				rec_bytes.buf[gb_ind++] = tmp;
				
				bit = 7;
				tmp = 0;
				
				// if a single flash.
				if (check_flash < 500)
				{
					// toggle bit is 0
					rec_bytes.buf[gb_ind++] = 0;
						
					// toggle bit is next byte
					lp++;
										
					// triple low means next bit is 1
					// can not use check_flash because of lp++
					if (rec_signal[lp].stop - rec_signal[lp].start > 1100)
						active_bit = 1;
					else
						active_bit = 0;

				}
				else
				{
					rec_bytes.buf[gb_ind++] = 1;	// set toggle bit
					
					// triple gap means next bit will be 0
					if (check_gap > 1100 )	active_bit = 0;	
					else active_bit = 1;			
				}
				
				if (DEBUG> 3) p_printf(4, "toggle bit is %x\n", rec_bytes.buf[gb_ind -1] );
			}
		
			else    	// end toggle bit detected
			{
				// if double flash active bit was 0, 
				//  but now also triggering the current bit is 1
				if (check_flash > 800)
				{
					// active_bit is now 1
					active_bit = 1;
				
					if (set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC6_bytes))
					{
						p_printf(2,"Received all bytes\n");
						break;
					}
				}
					
				// active_bit is now 0
				if (check_gap > 800 && check_gap < 80000 ) active_bit = 0;

			} // end else toggle			
		} // end started = 2
		
		if (check_gap > 80000)
		{
			if (DEBUG) p_printf(4,"Discovered start of repeat\n");
			break;	// break the loop
		}
			
	}	// end loop

	// if byte info pending, save it
	if (bit != 7)
	{
		if ( ! set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC6_bytes))
		{
			rec_bytes.buf[gb_ind++] = tmp;
	
			// number of bytes received
			rec_bytes.cnt = gb_ind;
		}
	}

	return(0);
}
/*
 * The RC-5  flah/ gap coding is opposite to RC-6
 * 1 = gap/flash = high/low
 * 0 = flash /gap = low /high
 * 
 * protocol (MSB first):
 * 
 * The leader code =  2 x 1 : S1 , S2
 * Toggle bit (reverses with each press)
 * 5 address bits
 * 6 command bits
 * 
 * The first low is actually the second half of the first '1' (S1).
 * so the bit counting starts with the high following the first low, which
 * is the first high for the second '1' (S2)
 * 
 * In some variant of the protocol (extended) the second '1' is replaced with this second 
 * start-bit (s2) is devoted as the 7th command bit. 
 * 
 */ 

int decode_data_rc5(int count)
{
	int lp;					// loop variables
	int started = 0;
	int active_bit = 1;		// current active bit
	int tmp;				// holds decoded byte
	int bit;				// MSB protocol
	int gb_ind;				// index to global buffer
	double check_gap, check_flash;
	
	p_printf(2, "Decoding RC-5 protocol\n");

	// set for RC5 encoding
	rec_bytes.type = RC5;
	
	for (lp = 0 ; lp < count -1 ; lp++)
	{
		// calculate results
		check_flash = rec_signal[lp].stop - rec_signal[lp].start;		// current flash
		check_gap =rec_signal[lp+1].start - rec_signal[lp].stop;		// current gap
		
		// find start of leader signal
		if (check_flash > 800 && check_flash < 950 
		&& check_gap > 800 && check_gap< 900 && started == 0 )
		{
			if (DEBUG) p_printf (2, "Found leader-signal flash: %f, gap: %f\n",check_flash,check_gap);
			started = 1;	// leader signal has been found
			gb_ind = 0;		// offset in buffer
			bit = 4;		// set for address = 5 bits
			tmp = 0;		// reset received byte 
		}
		
		// detect the active_bit based on the gap with the toggle bit after leader signal.
		else if (started == 1)
		{
			// if a single flash.
			if (check_flash < 950)
			{
				// toggle bit is 0
				rec_bytes.buf[gb_ind++] = 1;
				
				// toggle bit is next byte
				lp++;
									
				// double low means next bit is 0
				// can not use check_flash because of lp++
				if (rec_signal[lp].stop - rec_signal[lp].start > 1500)
					active_bit = 0;
				else
					active_bit = 1;

			}
			else
			{
				// toggle bit is 1
				rec_bytes.buf[gb_ind++] = 0;	// set toggle bit
				
				// double gap means next bit will be 1
				if (check_gap > 1500 )	active_bit = 1;
				else active_bit = 0;				
			}
			
			if (DEBUG) p_printf(4, "toggle bit is %x\n", rec_bytes.buf[gb_ind -1] );

			started = 2; 	// time to start decoding
		}
						
		// start decoding
		else if (started == 2)
		{
			// set active bit && save byte if last bit
			if (set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC5_bytes))
			{
				p_printf(2,"Done all bytes\n");
				break;
			}
			
			// in case new byte starting, data is only 6 in RC5
			if (bit == 7) 	bit = 5;

			// if double flash active bit was 1, 
			//  but now also triggering the current bit is 0
			if (check_flash > 1500)
			{
				// active_bit is now 1
				active_bit = 0;
			
				if (set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC5_bytes))
				{
					p_printf(2,"Received all bytes\n");
					break;
				}
			}
			
			// in case new byte starting, data is only 6 in RC5
			if (bit == 7) 	bit = 5;	
			
			// active_bit is now 0
			if (check_gap > 1000 && check_gap < 80000 ) active_bit = 1;

		} // end started = 2
		
		if (check_gap > 80000)
		{
			if (DEBUG) p_printf(4,"Detected start of repeat\n");
			break;	// break the loop
		}
			
	}	// end loop

	// if byte info pending, save it
	if (bit != 5)
	{
		if (! set_msb_bit(&bit, active_bit, &tmp, &gb_ind, RC5_bytes))
		{
			rec_bytes.buf[gb_ind++] = tmp;
	
			// number of bytes received
			rec_bytes.cnt = gb_ind;
		}
	}

	return(0);
}

/*
 *NEC protocol
 * lsb
 * leader 9ms
 * 1  >1000 us
 * 0  < 500 us
 */

int decode_data_nec(int count)
{
	int  lp;				// loop count 
	int  bit;				// bit count within byte
	int  tmp; 				// store the bytes in progress
	int  active_bit; 		// offset in local buf
	int  gb_ind=0;			// global buffer index
	int  started = 0;		// not yet started decoding
	double  check_gap, check_flash;

	p_printf(2, "Decoding NEC protocol\n");
	
	// set for NEC encoding
	rec_bytes.type = NEC;
	
	// not enough bits received
	if (count < NEC_bytes * 8) return(-1);
	
	for (lp = 0 ; lp < count -1 ; lp++)
	{
		// calculate results
		check_flash = rec_signal[lp].stop - rec_signal[lp].start;		// current flash
		check_gap =rec_signal[lp+1].start - rec_signal[lp].stop;		// current gap	
		
		
		/* detect NEC leader code (flash of 9ms)
		 * with the remote used to test, the signal was 9100 at real begin
		 * 8900 for repeat although both should be 9ms
		 * hence the value of 8800uS
		 */
		if (check_flash > 8800)
		{
			// leader code for starting transmission
			if (started == 0)
			{
				if (DEBUG > 0) printf ("NEC leader code was detected\n");
				started = 1;
			}
			
			// detected end of transmission current message
			else if (started == 2)
			{
				if (DEBUG > 1) printf ("complete / repeat signal detected\n");
				
				// break loop
				break;
			}
		}
		
		// Decode starts with gap after leader code  of 4.5ms
		if (check_gap > 4000 && check_gap < 4600 && started == 1)
		{
			started = 2; 	// gap has been found.. time to start
			gb_ind = 0;		// offset in buffer
			bit = tmp = 0;	// reset received byte & bit
		}
		
		// start decoding
		else if (started == 2)
		{
			// detect a 1- bit ( 1ms - 2 ms pulse)
			if (check_gap > 1000)	active_bit = 1;
			else active_bit = 0; 

			if (set_lsb_bit(&bit, active_bit, &tmp, &gb_ind, NEC_bytes))
			{
				if (DEBUG > 1) p_printf(2, "Received all bytes\n");
				break;
			}
		}
	}
	
	// check for correct code
	if ( (rec_bytes.buf[2] | rec_bytes.buf[3]) ==  0xff)
	{
		if (DEBUG > 1) p_printf(2, "CRC OK\n");
		return(0);		
	}
	
	p_printf(1, "CRC error\n");
	return(-1);
}


/* display decoded data */
void display_data()
{
	int	lp, found = 0;
	
	if (DEBUG > 1)
	{
		
		p_printf(1,"\nReceived bytes: \n");
		
		printf("HEX : "); 
		for (lp =0 ; lp < rec_bytes.cnt ; lp++)
				printf("%x ", rec_bytes.buf[lp]);
	
		printf("\nDEC : ");
		
		for (lp =0 ; lp < rec_bytes.cnt ; lp++)
				printf("%d ", rec_bytes.buf[lp]);
	
		printf("\n");
	}
	
	// decode Philips addresses
	if ( rec_bytes.type == RC6  || rec_bytes.type == RC5)
	{
		for (lp=0 ; lp < 31 ; lp++)
		{
			if (rec_bytes.type == RC5)
			{
				if  (rec_bytes.buf[1] == philips_add[lp].addr)
					p_printf(3,"Philips device is %s\n",philips_add[lp].desc );
			}
			else if (rec_bytes.type == RC6)
			{
				if(rec_bytes.buf[2] == philips_add[lp].addr)
				 p_printf(3,"Philips device is %s\n",philips_add[lp].desc );
			}

		}
	}
	
	// decode Sony addresses
	if ( rec_bytes.type == SONY)
	{
		lp = 0;
		do
		{
			if (rec_bytes.buf[1] == sony_add[lp].addr)
			{
				p_printf(3,"Sony device is %s\n",sony_add[lp].desc );
				break;
			}
			
			lp++;
		}while  (sony_add[lp].addr != 100);
	}
	
	// lookup button description
	lp=0;
	do
	{
		// check remote type
		if (descr[lp].type == rec_bytes.type)
		{
			// if check device address matches
			if (rec_bytes.buf[descr[lp].addr_b] == descr[lp].addr_c)
			{
				// check command /OBC matches
				if(rec_bytes.buf[descr[lp].offset] == descr[lp].command)
				{
					p_printf(2,"On device number 0x%x, button pressed:  %s \n",descr[lp].addr_c, descr[lp].desc);
					found++;
				}
			}
		}
		
		lp++;
			
	} while (descr[lp].type != END);
	
	if (found == 0 )
		p_printf(1, "Could not find info for device.\n");
	
}

/* display usage / help information */
void usage(char *name)
{
		p_printf(3,"%s [-n #] [-t #] [-d] [-h] [-T] \n"
		"\nversion 1.0 / May 2017\n"
		"Copyright (c)  2017 Paul van Haastrecht\n"
		"\n"
		"-n, 	Neglect pulse shorter than X us. (default: %1.0f us)\n"
		"-t, 	Set time-out seconds during reading signal. (default: %d seconds)\n"
		"-d, 	Enable debug messages.\n"
		"-T, 	Enable test pulse on GPIO 8.\n"
		"-h,	Show this help text\n\n",
		name, neglect_pulse, read_time_out );
}

int main(int argc, char *argv[])
{
	int cnt,c ;

	// catch signals
	set_signals();
	
	while (1)
	{
		c = getopt(argc, argv,"-n:t:dTh");

		if (c == -1)	break;
			
		switch (c) {
			case 'd':	// set debug level
				DEBUG = 2;
				break;
			case 'T':	// enable Test pin
				tst_pulse = 1;
				break;
			case 'n':	// change number of seconds to wait
				neglect_pulse = strtod(optarg,NULL);
				break;
			case 't':	// change number of seconds to wait
				read_time_out = (int) strtod(optarg,NULL);
				break;
			case 'h':
			default:	// display help
				usage(argv[0]);
				exit(0);
				break;			
		}
	}
	
	// setup GPIO 
	hw_init();
	
	while (1)
	{
		if ((cnt = read_signal())> 0)	
		{
			if (decode_data(cnt) == 0)
				display_data();
			else
				p_printf(1,"Nothing to display\n");
		}
		
		if (yes_or_no("press yes to continue or no to stop\n") ==  0)
			break;
	}
	
	// reset the hardware
	close_out(0);
	
	exit(0);
}
