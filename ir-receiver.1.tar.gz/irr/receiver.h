/* header file for IR receiver 
 * 
 * Copyright (c) 2017 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */

#include "decode.h"

/* receiver POWER */
#define power_pin 	RPI_V2_GPIO_P1_32	// GPIO12
#define ON  1
#define OFF 0

/* receiver input */
#define rec_pin 	RPI_V2_GPIO_P1_36 // GPIO 16

/* test pulse output */
#define pin_tst_pulse 8		//GPIO 8

/* display color */
#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

/*store received data */
typedef struct {
	double start;				// time stamp start low
	double stop;				// time stamp stop low
} store_rec;
#define MAX_COUNT	300			// number of samples for the signal received

#define MAX_BUF	50				// max size of decoded bytes
typedef struct {
	int		cnt;				// amount of bytes in buffer
	char 	buf[MAX_BUF];		// holds decoded signal
	Remote 	type;				// hold the type of control
} decode_rec;



/* setup hardware  */
void hw_init();

/* end the program correctly */
void close_out(int end);

/* handle power ON or OFF for receiver */
void rec_power(int act);

/* catch signals to close out correctly */
void signal_handler(int sig_num);

/* setup signals */
void set_signals();

/* display debug message
 * @param format : debug message to display and optional arguments
 *                 same as printf
 * @param level :  1 = RED, 2 = GREEN, 3 = YELLOW 4 = blue
 * info is only displayed if DEBUG had set for it*/
void p_printf (int level, char *format, ...);

/* get yes (1) or No (0) */
int yes_or_no(char *mess);

/* return current time in useconds */
double get_current();

/* display decoded data */
void display_data();

/* decode routines */
int decode_data(int count);
int decode_data_nec(int count);
int decode_data_daikin(int count);
int decode_data_rc6(int count);
int decode_data_rc5(int count);
int decode_data_sony(int count);

/* calculate the Daikin CRC 
 * return 0 = OK, -1 = ERROR */
int daikin_crc(int start_ind, int end_ind);

/* set bit value (either 0 or 1) & save byte if complete
 * bit = bit to set 
 * val = 0 or 1
 * tmp = byte to update
 * index = offset rec_bytes.buf
 * num_bytes = total amount of bytes expected
 * 
 * return 
 * 1 all bytes received
 * 0 not all bytes received
 */
int set_lsb_bit(int *bit, int val, int *tmp, int * index, int num_bytes);
int set_msb_bit(int *bit, int val, int *tmp, int * index, int num_bytes);
